{
    "name": "Theme LawFirm",
    "version": "18.0.1.0.0",
    "category": "Theme/Services",
    "summary": "Professional Law Firm Theme",
    "description": "A prestigious theme for law firms with attorney profiles and practice areas",
    "author": "Platxa",
    "website": "https://platxa.com",
    "license": "LGPL-3",
    "depends": ["website"],
    "data": ["views/layout.xml", "views/homepage.xml", "views/attorneys.xml", "views/practice_areas.xml"],
    "assets": {
        "web.assets_frontend": [
            "theme_lawfirm/static/src/scss/theme.scss"
        ]
    },
    "installable": True
}