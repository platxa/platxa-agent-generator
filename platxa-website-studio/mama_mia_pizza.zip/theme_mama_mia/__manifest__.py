{
    "name": "Theme Mama Mia",
    "version": "18.0.1.0.0",
    "category": "Theme/Food",
    "summary": "Italian Pizza Restaurant Theme",
    "description": "A warm and inviting theme for Mama Mia Pizza restaurant",
    "author": "Platxa",
    "website": "https://platxa.com",
    "license": "LGPL-3",
    "depends": ["website"],
    "data": ["views/homepage.xml"],
    "assets": {
        "web.assets_frontend": [
            "theme_mama_mia/static/src/scss/theme.scss"
        ]
    },
    "installable": True
}